#pragma once
#include "VECTOR2.h"
#include <string>
class Button
{
public:
	Button();
	Button(std::string name, VECTOR2 pos, VECTOR2 size);
	Button(std::string name, VECTOR2 pos, VECTOR2 size, int setNum);

	~Button();


	void Update();
	void Draw(unsigned int color = 0xaaaaaa);
	void AddPos(VECTOR2 vec);
	void SetPos(VECTOR2 pos);
	void SetPosForX(int x, int size);

	bool GetHitCheck(VECTOR2 pos);
	const std::string& GetString();
	const VECTOR2& GetPos();

	const int& GetNum();
	void AddNum(int num);
	void SubNum(int num);

private:
	//���S�_
	VECTOR2 _pos;
	VECTOR2 _size;
	std::string _name;

	int _num = 0;
};

