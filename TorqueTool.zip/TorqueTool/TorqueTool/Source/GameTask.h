#pragma once
#include <string>
#include <vector>
#include <memory>
#include "VECTOR2.h"
#include <Windows.h>

#define  lpGameTask GameTask::GetInstance()

constexpr int SCREEN_SIZE_X = 720;
constexpr int SCREEN_SIZE_Y = 610;
constexpr int GAME_SIZE_X = 600;
constexpr int GAME_SIZE_Y = 550;
constexpr int SCREEN_CENTER_X = GAME_SIZE_X / 2;
constexpr int SCREEN_CENTER_Y = GAME_SIZE_Y / 2;

constexpr int CHECK_CNT = 10;

enum G_MODE {
	G_INIT,
	G_MAIN,
	G_MAX
};

class GameTask
{
public:
	// �ݸ����
	static void Create(void);
	static GameTask &GetInstance(void)
	{
		Create();
		return *s_Instance;
	}


	int SystemInit();		// �V�X�e��������
	void GameUpdate(HINSTANCE hInstance);		// �Q�[�����[�v
	void GameInit();		// �Q�[�����e�̐���ϐ��ȂǏ�����
	void GameMain();		// �Q�[����

	float Upload(float a, float b);
	void Upload();
	void ExternUpload();
	void Open(HINSTANCE hInstance);

	const bool& GetFlag()
	{
		return _saveFlag;
	}

private:
	static GameTask *s_Instance;

	void (GameTask::*gMode[G_MAX])() = { &GameTask::GameInit,&GameTask::GameMain };	


	int currentMode = -1;		// ���݂̃��[�h
	bool _popFlag = false;
	bool _checkFlag = false;
	int _lineCnt = 0;
	bool _finishFlag = false;	// �v�Z�J�n
	bool _UICheckFlag = false;
	bool extendFlag = false;
	bool _saveFlag = false;

	int handle = 0;
	VECTOR2 _startPos = { 0,0 };
	VECTOR2 _enemyStart = { 0,0 };

	std::vector<std::vector<VECTOR2>> _enemyVec;
	HINSTANCE _hInstance;

	//��]���̍ő�l
	int _outputMax = 5000;
	int _torqueMax = 5000;

	int _boxTorque = 500;
	int _boxOutput = 5000;

	//��]��
	std::vector<int> _output;
	std::vector<int> _torque;

	//�o��
	std::vector<float> _input;
};


