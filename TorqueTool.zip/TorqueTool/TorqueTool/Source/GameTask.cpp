#include "DxLib.h"
#include "GameTask.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include "MouseMng.h"
#include "KeyMng.h"
#include "Button.h"


GameTask *GameTask::s_Instance = nullptr;

std::vector<std::shared_ptr<Button>> _button;


#define P 6.28318530718

struct Data
{
	int size;
};


#define BBM_ID_NAME "BBM_MAP_DATA"	// ̧�َ��
#define BBM_VER_ID 0x01				// ̧���ް�ޮ�


void GameTask::Create(void)
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("TorqueCurve");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);

}

void GameTask::GameUpdate(HINSTANCE hInstance)
{
	_hInstance = hInstance;
	// ���݂̃��[�h�ŉ�
	(this->*gMode[currentMode])();
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xffffff);

	_button.emplace_back(std::make_shared<Button>("�g���N",VECTOR2(GAME_SIZE_X + 25,50), VECTOR2(64,32), _boxTorque));
	_button.emplace_back(std::make_shared<Button>("��]��", VECTOR2(GAME_SIZE_X + 25, 100), VECTOR2(64, 32), _boxOutput));
	_button.emplace_back(std::make_shared<Button>("�v�Z�o��", VECTOR2(GAME_SIZE_X + 25, 150), VECTOR2(64, 32)));


	//--------------------------------------------------
	// ������
	//--------------------------------------------------
	currentMode = G_INIT;

	currentMode = G_MAIN;

}

void GameTask::GameMain()
{
	int _getMeterCnt = 0;

	DrawBox(GAME_SIZE_X, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, GetColor(100, 150, 50), true);

	DrawString(GAME_SIZE_X, 200, "�������", 0xffffff);
	DrawString(GAME_SIZE_X, 250, "���N���b�N:", 0xffffff);
	DrawString(GAME_SIZE_X + 50, 275, "�l�̑���", 0xffffff);
	DrawString(GAME_SIZE_X, 300, "�E�N���b�N:", 0xffffff);
	DrawString(GAME_SIZE_X + 50, 325, "�l�̌���", 0xffffff);

	DrawString(GAME_SIZE_X, 375, "�v�Z�o��:", 0xffffff);
	DrawString(GAME_SIZE_X , 400, "�g���N�J�[�u", 0xffffff);
	DrawString(GAME_SIZE_X + 65, 425, "���Z�o", 0xffffff);

	MouseMng::GetInstance().Update();
	KeyMng::GetInstance().Update();

	int Mx, My;
	bool uploadFlag = false;

	GetMousePoint(&Mx, &My);

	for (auto& b : _button)
	{
		b->Draw();

		if (MouseMng::GetInstance().trgKey[P1_PUSH] && b->GetHitCheck(VECTOR2(Mx,My)))
		{
			if (b->GetString() == "�g���N")
			{
				b->AddNum(50);
			}
			if (b->GetString() == "��]��")
			{
				b->AddNum(500);
			}
			if (b->GetString() == "�v�Z�o��")
			{
				if (!_finishFlag)
				{
					_finishFlag = true;
				}
				
			}

		}
		else if (MouseMng::GetInstance().trgKey[P1_POP] && b->GetHitCheck(VECTOR2(Mx, My)))
		{
			if (b->GetString() == "�g���N" && b->GetNum() > 50)
			{
				b->SubNum(50);

			}
			if (b->GetString() == "��]��" && b->GetNum() > 500)
			{
				b->SubNum(500);

			}
		}

		if (b->GetString() == "�g���N")
		{
			_outputMax = b->GetNum();
		}
		if (b->GetString() == "��]��")
		{
			_torqueMax = b->GetNum();
		}
	}
	

	int cntX = 0;

	//��]��
	auto outputCnt = (5000 / (CHECK_CNT*CHECK_CNT));


	for (int j = GAME_SIZE_Y / outputCnt; j > 0; j--)
	{
		if (_output.size() <= CHECK_CNT)
		{
			_output.emplace_back(0);
		}

		auto posY = j * outputCnt;
		if (j == GAME_SIZE_Y / outputCnt)
		{
			DrawBox(50, posY - 2, GAME_SIZE_X - outputCnt, posY + 2, 0xffffff, true);
		}
		DrawLine(50, posY, GAME_SIZE_X - outputCnt, posY, 0xffffff, true);

		int i = (cntX) * _outputMax / CHECK_CNT;

		_output[cntX] = i * 10;
		cntX++;
		DrawFormatString(10, posY - 10, 0xffffff, "%d", i);

	}

	//�g���N
	auto torqueCnt = (5000 / (CHECK_CNT*CHECK_CNT));
	cntX = 0;
	for (int j = 1; j < GAME_SIZE_X / torqueCnt; j++)
	{
		if (_torque.size() <= CHECK_CNT)
		{
			_torque.emplace_back(0);
		}

		auto posX = j * torqueCnt;
		if (j == 1)
		{
			DrawBox(posX -2, 0, posX +2, GAME_SIZE_Y, 0xffffff, true);
		}
		DrawLine(posX, 0, posX, GAME_SIZE_Y, 0xffffff, true);

		int i = (j - 1) * (_torqueMax / (CHECK_CNT*CHECK_CNT));
		_torque[cntX] = i;
		cntX++;

		DrawFormatString(posX - 10, GAME_SIZE_Y + 10, 0xffffff, "%d", i* 10);
	}

	cntX = 0;

	for (int j = 0; j < _output.size(); j++)
	{
		auto posX = j * torqueCnt;

		if (_input.size() <= CHECK_CNT)
		{
			_input.emplace_back(0);
		}


		if (_finishFlag)
		{
			_input[cntX] = Upload(_torque[cntX], _output[cntX]);

		}
		if (posX > 0 && _input[cntX] > 0)
		{
			DrawCircle(posX + 50, (GAME_SIZE_X - 50) - _input[cntX], 3, GetColor(255, 0, 0), true);
			DrawFormatString(posX + 50, (GAME_SIZE_X - 50) - _input[cntX] - 20, 0x00ff00, "%d", (int)_input[cntX]);

			if (cntX > 1)
			{
				auto line1 = (GAME_SIZE_X - 50) - _input[cntX];
				auto line2 = (GAME_SIZE_X - 50) - _input[cntX-1];
				DrawLine(posX + 50, line1, posX, line2, 0x00ff00, true);
			}
		}

		cntX++;

	}

	_finishFlag = false;
}

float GameTask::Upload(float a, float b)
{
	return P * a * b / 60 / 1000;
}

void GameTask::Upload()
{

}

void GameTask::ExternUpload()
{

}

void GameTask::Open(HINSTANCE hInstance)
{

}


